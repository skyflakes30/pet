# Ghost Pocket — Moonveil Adventure
An original creature adventure made for Sky. Hatch a Moonseed into **Wicklet → Glimveil → Noctilume**, build a cozy home, explore three regions, meet nine wild creatures, and fight turn-based battles.

## Play and run
Open `index.html` or serve the folder with `python3 -m http.server 8080`. No runtime dependencies, API keys, paid accounts, or build step are required for the browser game. Hosted over HTTPS, it supports Add to Home Screen and offline play after its first successful load. This is a solo adventure against computer-controlled creatures, not multiplayer. Saves remain on each device/browser; online hosting does not provide account or cross-device synchronization.

## Features
- Original SVG companion art, four life stages, nine original wild creatures.
- Home care, real-time rest, HP/energy/fullness/happiness, bond, XP and levels.
- Whisperwood, Ember Hollow (level 3), Moonwell Ruins (level 6).
- Attack, strong skill with focus cost, guard, potions, safe retreat and defeat.
- Every third enemy turn is a heavy strike. Guard reduces damage by 65%.
- Furniture purchases appear in the cottage. Quest rewards are claimable once.
- Field guide records encountered and defeated creatures.
- Browser-local autosave, persistent encounters, JSON save export/import.
- Original v1 saves can migrate to equivalent original-creature stages.

## Evolution
Moonseed hatches after 5 taps. Wicklet evolves at level 4 + 40 bond; Glimveil evolves at level 8 + 100 bond. Victories give 10 bond plus enemy-specific XP/coins. Full care meters cannot farm affection. Rest restores 2 HP and 1.5 energy per real minute, capped at eight hours per absence. A companion never dies.

## Widgets
See `native/README.md`. Android source includes an app and home-screen widget with a pet button. iOS source includes a WKWebView app, interactive home-screen WidgetKit widget, and a Lock Screen glance widget. Both native widgets share the installed app's on-device state. They do not share browser saves or cross-device state automatically.

The native projects are source deliverables: no signed APK/IPA is included. Their build and device behavior have not been verified in this Linux environment. Android Studio/Android SDK and a Mac with Xcode are required respectively. Browser backup/import is verified only in the browser; native WebView file pickers/downloads are not implemented.

## Checks and deployment
`npm run check` and `npm test` (Node 22+). Six engine tests cover hatching/migration, save persistence, battle rules/rewards, guard/defeat, quests/purchases/evolution, and rest/save validation. Browser QA covered encounters, combat, reload persistence, victory rewards, and furniture placement. No native build or device test was possible here.

For GitHub Pages, publish these web files at the repository root and select main/root in Settings → Pages. All asset paths are relative. `.github/workflows/check.yml` runs the checks.

All creature names and illustrations are original to this fan-inspired game. There are no Pokémon names or official sprites in the current game. The project has no analytics, advertisements, or third-party asset requests.

## Visual update (v3)
Warm illustrated cottage and woodland environments, shaded vector creatures, original SVG controls, richer island map, compact mobile navigation, companion evolution rail, and battle damage feedback. Current save keys and gameplay rules are preserved. Environment assets were generated with the built-in image tool, then exported as optimized WebP. Briefs: a handcrafted amber-lit woodland cottage with an empty central floor, and a moonlit bioluminescent forest clearing with open combat ground. Native widget creature PNGs use the updated vector artwork.

## Combat effects (v4)
Player cast/projectile/impact animations precede the enemy counterattack. Spirit tap, Lantern burst, guard and tonic have distinct feedback. Wild attacks use Leaf, Stone, Mist, Ember, Spark, Frost or Shade colors. Control locking prevents overlapping turns; the resolved state is saved before animation, so reloading cannot duplicate rewards. Victory/defeat summaries show the completed encounter. Motion preferences and system reduced-motion settings are respected. Each region now has its own environment artwork.
