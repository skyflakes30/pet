# Ghost Pocket native apps and widgets

These are editable source projects, not installed or signed apps. No native build or device test has been run here. The online web game works separately; a website installed to the Home Screen does not create a native interactive widget.

## Android
1. Open `android/` in Android Studio. Use JDK 17, Android SDK 35 and the Gradle version compatible with Android Gradle Plugin 8.7.3 (Gradle 8.9).
2. Let Android Studio sync dependencies. Build and run the app on Android 8.0+.
3. Open the app once and hatch or start the Moonseed. Long-press your phone's Home Screen → Widgets → Ghost Pocket.
4. Add the resizable widget. Its pet button warms the Moonseed or adds affection; tapping the creature opens the adventure.

There is no Gradle wrapper binary in this source package. If using a local Gradle 8.9 installation, run `gradle wrapper --gradle-version 8.9`, then `./gradlew assembleDebug`. Android Studio can also generate/configure the wrapper. Debug APK installation must be completed on the phone. Never commit release keystores.

The WebView loads only bundled assets from a restricted local HTTPS origin. A narrow save bridge shares the same JSON save with the widget in SharedPreferences. The app refreshes that state on resume. Petting is blocked while sleeping or in battle; normal full-meter limits and evolution conditions apply. Widget refreshes depend on Android launcher behavior, not continuous animation. App widgets are snapshots, not a floating pet overlay.

## iPhone / iPad
1. On a Mac, install Xcode and XcodeGen, then run `xcodegen generate` inside `ios/`.
2. Open `GhostPocket.xcodeproj`. Set your Apple developer Team and unique bundle IDs on both app and widget targets.
3. Create/enable an App Group for both targets. Replace `group.com.skyvion.ghostpocket` consistently in both entitlement files and `Shared/PetStore.swift` with your actual provisioned group.
4. Build and run the app on iOS 17+. Distribution/TestFlight requires your own signing/provisioning and applicable Apple membership. No signing credentials are included.
5. Open the app once, then add Ghost Pocket from the Home Screen widget gallery. Small/medium widgets show your pet and a Pet button using AppIntent. The accessory rectangular Lock Screen widget is a glance/shortcut, not interactive petting.

App and extension share an App Group JSON save. PetIntent changes that shared save and requests a WidgetKit timeline reload. The app refreshes its native save when it becomes active. Widget updates are subject to OS scheduling and are not continuous animations. iOS does not allow this pet to float over unrelated apps.

## Saves and limitations
The browser, Android installation, and iOS installation each own independent local progress. Cloud saves, online player battles, accounts, native file backup pickers/downloads, push notifications, and store publication are not implemented. Do not assume the online website automatically syncs with a native widget.

## Keeping the embedded game current
Run `python3 scripts/sync_native_assets.py` from the repository root after web edits. Creature PNGs are provided in the Android drawable and iOS Creatures folders. Keep native petting/evolution logic aligned with `engine.js` if you change game rules.
