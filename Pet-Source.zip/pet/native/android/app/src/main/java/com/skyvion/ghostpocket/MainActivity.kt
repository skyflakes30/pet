package com.skyvion.ghostpocket
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.addJavascriptInterface(object {
            @JavascriptInterface fun load(): String = getSharedPreferences("pet", MODE_PRIVATE).getString("save", "") ?: ""
            @JavascriptInterface fun save(json: String) {
                try { if (JSONObject(json).optInt("version") != 2) return } catch (_: Exception) { return }
                getSharedPreferences("pet", MODE_PRIVATE).edit().putString("save", json).apply()
                runOnUiThread { PetWidget.refresh(this@MainActivity) }
            }
        }, "GhostNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = request.url.host != "ghost.local"
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse {
                val path = request.url.path?.removePrefix("/")?.ifBlank { "index.html" } ?: "index.html"
                if (request.url.host != "ghost.local" || path.contains("..")) return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                return try {
                    val mime = when(path.substringAfterLast('.')) { "html" -> "text/html"; "js" -> "application/javascript"; "css" -> "text/css"; "svg" -> "image/svg+xml"; "json", "webmanifest" -> "application/json"; else -> "application/octet-stream" }
                    WebResourceResponse(mime, "UTF-8", assets.open("game/$path"))
                } catch (_: Exception) { WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0))) }
            }
        }
        setContentView(web)
        web.loadUrl("https://ghost.local/index.html")
    }
    override fun onResume() { super.onResume(); if (::web.isInitialized) web.evaluateJavascript("window.ghostResume && window.ghostResume()", null) }
    override fun onDestroy() { web.removeJavascriptInterface("GhostNative"); web.destroy(); super.onDestroy() }
}
