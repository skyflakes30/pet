package com.skyvion.ghostpocket
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONObject
import kotlin.math.min
import kotlin.math.max

class PetWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { refresh(context) }
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == "com.skyvion.ghostpocket.PET") {
            val prefs = context.getSharedPreferences("pet", Context.MODE_PRIVATE)
            try {
                val s = JSONObject(prefs.getString("save", "") ?: "")
                if (s.optInt("version") == 2 && s.isNull("battle") && !s.optBoolean("sleeping")) {
                    val now = System.currentTimeMillis()
                    val stage = s.optInt("stage")
                    if (stage == 0) { s.put("warmth", min(5, s.optInt("warmth") + 1)); if (s.optInt("warmth") >= 5) s.put("stage", 1) }
                    else if (now - s.optLong("lastCare") >= 1500) {
                        val minutes = min(480.0, max(0.0, (now - s.optLong("updatedAt")) / 60000.0))
                        for ((key, rate) in listOf("hunger" to .12, "cleanliness" to .08, "happiness" to .06, "energy" to .08)) s.put(key, max(0.0, s.optDouble(key) - minutes * rate))
                        if (s.optDouble("happiness") < 99) { s.put("happiness", min(100.0, s.optDouble("happiness") + 8)); s.put("bond", s.optInt("bond") + 3); s.put("lastCare", now) }
                        if (s.optInt("stage") == 1 && s.optInt("level") >= 4 && s.optInt("bond") >= 40) s.put("stage", 2)
                        if (s.optInt("stage") == 2 && s.optInt("level") >= 8 && s.optInt("bond") >= 100) s.put("stage", 3)
                        if (s.optInt("stage") != stage) s.put("hp", 55 + (s.optInt("level") - 1) * 9 + max(0, s.optInt("stage") - 1) * 10)
                    }
                    s.put("updatedAt", now)
                    prefs.edit().putString("save", s.toString()).apply()
                }
            } catch (_: Exception) { }
            refresh(context)
        }
    }
    companion object {
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, PetWidget::class.java))
            val s = try { JSONObject(context.getSharedPreferences("pet", Context.MODE_PRIVATE).getString("save", "") ?: "") } catch (_: Exception) { null }
            for (id in ids) {
                val view = RemoteViews(context.packageName, R.layout.pet_widget)
                val stage = s?.optInt("stage")?.coerceIn(0, 3) ?: 0
                val names = listOf("Moonseed", "Wicklet", "Glimveil", "Noctilume")
                view.setTextViewText(R.id.pet_name, s?.optString("nickname")?.ifBlank { names[stage] } ?: "Your little wonder")
                view.setTextViewText(R.id.pet_stats, if(s == null) "Open to begin your adventure" else "Lv ${s.optInt("level")} · ♡ ${s.optInt("bond")} bond")
                view.setTextViewText(R.id.pet_button, when { s == null -> "Begin adventure"; !s.isNull("battle") -> "In battle · Open"; s.optBoolean("sleeping") -> "Resting · Open"; stage == 0 -> "Warm egg · ${s.optInt("warmth")}/5"; else -> "Pet ♡" })
                view.setImageViewResource(R.id.pet_image, listOf(R.drawable.pet_0, R.drawable.pet_1, R.drawable.pet_2, R.drawable.pet_3)[stage])
                val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val pet = PendingIntent.getBroadcast(context, 1, Intent(context, PetWidget::class.java).setAction("com.skyvion.ghostpocket.PET"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                view.setOnClickPendingIntent(R.id.widget_root, open)
                view.setOnClickPendingIntent(R.id.pet_button, if(s == null || !s.isNull("battle") || s.optBoolean("sleeping")) open else pet)
                manager.updateAppWidget(id, view)
            }
        }
    }
}
