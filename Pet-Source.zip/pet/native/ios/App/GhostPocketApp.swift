import SwiftUI
import WebKit
import WidgetKit

@main struct GhostPocketApp: App {
    var body: some Scene { WindowGroup { GameWebView().ignoresSafeArea(edges: .bottom).preferredColorScheme(.dark) } }
}
struct GameWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.userContentController.add(context.coordinator, name: "ghostSave")
        config.userContentController.addUserScript(WKUserScript(source: Coordinator.nativeJS(), injectionTime: .atDocumentStart, forMainFrameOnly: true))
        let view = WKWebView(frame: .zero, configuration: config)
        view.isOpaque = false
        view.backgroundColor = UIColor(red: 0.094, green: 0.110, blue: 0.161, alpha: 1)
        view.navigationDelegate = context.coordinator
        context.coordinator.webView = view
        context.coordinator.observe()
        if let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Game") { view.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent()) }
        return view
    }
    func updateUIView(_ view: WKWebView, context: Context) {}
    class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        weak var webView: WKWebView?
        var observer: NSObjectProtocol?
        static func nativeJS() -> String {
            let escaped = (try? JSONSerialization.data(withJSONObject: [PetStore.raw])).flatMap { String(data: $0, encoding: .utf8) } ?? "[\"\"]"
            return "window.__NATIVE_SAVE__ = (\(escaped))[0];"
        }
        func observe() { observer = NotificationCenter.default.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { [weak self] _ in self?.webView?.evaluateJavaScript(Self.nativeJS() + "window.ghostResume && window.ghostResume();", completionHandler: nil) } }
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) { if message.name == "ghostSave", let json = message.body as? String { PetStore.save(json); webView?.evaluateJavaScript(Self.nativeJS(), completionHandler: nil); WidgetCenter.shared.reloadAllTimelines() } }
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) { decisionHandler(navigationAction.request.url?.isFileURL == true ? .allow : .cancel) }
        deinit { if let observer { NotificationCenter.default.removeObserver(observer) } }
    }
}
