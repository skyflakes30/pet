import Foundation

enum PetStore {
    // Set this App Group on BOTH targets under Signing & Capabilities.
    static let group = "group.com.skyvion.ghostpocket"
    static var defaults: UserDefaults { UserDefaults(suiteName: group)! }
    static var raw: String { defaults.string(forKey: "save") ?? "" }
    static var state: [String: Any] { (try? JSONSerialization.jsonObject(with: Data(raw.utf8))) as? [String: Any] ?? [:] }
    static let names = ["Moonseed", "Wicklet", "Glimveil", "Noctilume"]
    static func save(_ json: String) { guard let data = json.data(using: .utf8), let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any], obj["version"] as? Int == 2 else { return }; defaults.set(json, forKey: "save") }
    static func number(_ s: [String: Any], _ k: String) -> Double { (s[k] as? NSNumber)?.doubleValue ?? 0 }
    static func pet() {
        var s = state
        guard s["version"] as? Int == 2, s["sleeping"] as? Bool != true, s["battle"] is NSNull else { return }
        let now = Date().timeIntervalSince1970 * 1000
        let stage = Int(number(s, "stage"))
        if stage == 0 { s["warmth"] = min(5, number(s, "warmth") + 1); if number(s, "warmth") >= 5 { s["stage"] = 1 } }
        else if now - number(s, "lastCare") >= 1500 {
            let minutes = min(480, max(0, (now - number(s, "updatedAt")) / 60000))
            for (key, rate) in [("hunger", 0.12), ("cleanliness", 0.08), ("happiness", 0.06), ("energy", 0.08)] { s[key] = max(0, number(s, key) - minutes * rate) }
            if number(s, "happiness") < 99 { s["happiness"] = min(100, number(s, "happiness") + 8); s["bond"] = number(s, "bond") + 3; s["lastCare"] = now }
            if number(s, "stage") == 1 && number(s, "level") >= 4 && number(s, "bond") >= 40 { s["stage"] = 2 }
            if number(s, "stage") == 2 && number(s, "level") >= 8 && number(s, "bond") >= 100 { s["stage"] = 3 }
            if number(s, "stage") != Double(stage) { s["hp"] = 55 + (number(s, "level") - 1) * 9 + max(0, number(s, "stage") - 1) * 10 }
        }
        s["updatedAt"] = now
        if let data = try? JSONSerialization.data(withJSONObject: s), let json = String(data: data, encoding: .utf8) { save(json) }
    }
}
