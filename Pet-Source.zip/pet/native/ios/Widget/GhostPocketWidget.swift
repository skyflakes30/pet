import WidgetKit
import SwiftUI
import AppIntents
import UIKit

struct PetEntry: TimelineEntry { let date: Date; let state: [String: Any] }
struct PetProvider: TimelineProvider {
    func placeholder(in context: Context) -> PetEntry { PetEntry(date: Date(), state: ["stage": 1, "level": 1, "bond": 0]) }
    func getSnapshot(in context: Context, completion: @escaping (PetEntry) -> Void) { completion(PetEntry(date: Date(), state: PetStore.state)) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<PetEntry>) -> Void) { completion(Timeline(entries: [PetEntry(date: Date(), state: PetStore.state)], policy: .after(Date().addingTimeInterval(1800)))) }
}
struct PetCompanionIntent: AppIntent {
    static var title: LocalizedStringResource = "Pet your companion"
    static var description = IntentDescription("Warm your Moonseed or give your companion a little love.")
    func perform() async throws -> some IntentResult { PetStore.pet(); WidgetCenter.shared.reloadAllTimelines(); return .result() }
}
struct PetWidgetView: View {
    let entry: PetEntry
    @Environment(\.widgetFamily) var family
    var stage: Int { min(3, max(0, Int(PetStore.number(entry.state, "stage")))) }
    var name: String { let nickname = entry.state["nickname"] as? String ?? ""; return nickname.isEmpty ? PetStore.names[stage] : nickname }
    var body: some View {
        if family == .accessoryRectangular {
            HStack { Image(systemName: "sparkles"); VStack(alignment: .leading) { Text(name).bold(); Text("Lv \(Int(PetStore.number(entry.state, "level"))) · ♡ \(Int(PetStore.number(entry.state, "bond")))") } }.widgetURL(URL(string: "ghostpocket://home")).containerBackground(.fill.tertiary, for: .widget)
        } else {
            VStack(spacing: 5) {
                Text(name).font(.system(size: 15, weight: .semibold)).lineLimit(1)
                if let url = Bundle.main.url(forResource: "pet_\(stage)", withExtension: "png", subdirectory: "Creatures"), let image = UIImage(contentsOfFile: url.path) { Image(uiImage: image).resizable().scaledToFit().frame(maxHeight: family == .systemSmall ? 65 : 90) }
                Text(entry.state.isEmpty ? "Open the app to begin" : "Lv \(Int(PetStore.number(entry.state, "level"))) · ♡ \(Int(PetStore.number(entry.state, "bond"))) bond").font(.system(size: 10)).foregroundStyle(.secondary)
                if entry.state.isEmpty || entry.state["sleeping"] as? Bool == true || !(entry.state["battle"] is NSNull) {
                    Link(entry.state.isEmpty ? "Begin adventure" : "Open adventure", destination: URL(string: "ghostpocket://home")!).font(.system(size: 11))
                } else {
                    Button(intent: PetCompanionIntent()) { Text(stage == 0 ? "Warm Moonseed ♡" : "Pet ♡").font(.system(size: 11)).padding(.horizontal, 8) }.buttonStyle(.bordered)
                }
            }.widgetURL(URL(string: "ghostpocket://home")).containerBackground(Color(red: 0.16, green: 0.17, blue: 0.24), for: .widget)
        }
    }
}
@main struct GhostPocketWidget: Widget {
    let kind = "GhostPocketWidget"
    var body: some WidgetConfiguration { StaticConfiguration(kind: kind, provider: PetProvider()) { PetWidgetView(entry: $0) }.configurationDisplayName("Your little wonder").description("Keep your companion close. Tap to give it a little love.").supportedFamilies([.systemSmall, .systemMedium, .accessoryRectangular]) }
}
