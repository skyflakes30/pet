from pathlib import Path
import shutil
root = Path(__file__).resolve().parents[1]
for relative in ['dist', 'native/android/app/src/main/assets/game', 'native/ios/Resources/Game']:
    folder = root / relative
    folder.mkdir(parents=True, exist_ok=True)
    for name in ['index.html', 'style.css', 'engine.js', 'app.js', 'art.js', 'sw.js', 'icon.svg', 'manifest.webmanifest', 'cottage-v3.webp', 'woodland-v3.webp']:
        shutil.copy2(root / name, folder / name)
print('Browser and native assets synchronized.')
